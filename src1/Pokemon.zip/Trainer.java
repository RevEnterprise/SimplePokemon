import java.util.ArrayList;

public class Trainer {

    private String name;
    private int col;
    private int row;

    private ArrayList<Pokemon> pokemon;
    private ArrayList<Item> items;

    public Trainer(String name, int startCol, int startRow) {
        this.name = name;
        this.col = startCol;
        this.row = startRow;

        pokemon = new ArrayList<>();
        items = new ArrayList<>();
    }

    public String getName() { return name; }

    public ArrayList<Pokemon> getPokemon() { return pokemon; }
    public ArrayList<Item> getItems() { return items; }

    public int getCol() { return col; }
    public int getRow() { return row; }

    /** Add one Pokémon to trainer's roster */
    public void addPokemon(Pokemon p) {
        if (p != null) pokemon.add(p);
    }

    /** Add an item to trainer inventory */
    public void addItem(Item item) {
        if (item != null) items.add(item);
    }

    public void move(int dx, int dy, int maxCols, int maxRows) {
        int newCol = col + dx;
        int newRow = row + dy;

        if (newCol >= 0 && newCol < maxCols && newRow >= 0 && newRow < maxRows) {
            col = newCol;
            row = newRow;
        }
    }

    public void arrangePokemon(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= pokemon.size()) return;
        if (toIndex < 0 || toIndex >= pokemon.size()) return;

        Pokemon p = pokemon.remove(fromIndex);
        pokemon.add(toIndex, p);
    }
}

