public class PlayerTrainer extends Trainer {

    public PlayerTrainer(String name, int startCol, int startRow) {
        super(name, startCol, startRow);

        // Add starting Pokémon
        addPokemon(new Pokemon("Bulbasaur"));
        addPokemon(new Pokemon("Charmander"));
        addPokemon(new Pokemon("Squirtle"));

        // Add starting items
        addItem(new Item("Potion", 3));
    }
}

