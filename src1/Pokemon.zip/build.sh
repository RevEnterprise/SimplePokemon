#!/bin/bash

rm *.class
javac GameApp.java
java GameApp

