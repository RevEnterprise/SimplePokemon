public class Pokemon {

    private String name;

    public Pokemon(String name) {
        this.name = name;
    }

    // Copy constructor (optional but useful)
    public Pokemon(Pokemon other) {
        this.name = other.name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}

