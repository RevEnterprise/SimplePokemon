import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WorldPanel extends JPanel implements KeyListener {

    private int screenW, screenH;
    private int tileSize = 48;
    private int cols = 10, rows = 10;
    private int gridW, gridH, gridX, gridY;

    private PlayerTrainer player;              // renamed from trainer → player
    private Trainer npcLeft;                   // new NPC trainer (left side)
    private Trainer npcRight;                  // new NPC trainer (right side)
    private PokemonCenter pokeCenter;

    private MusicSystem music;
    private JFrame parent;

    public WorldPanel(int w, int h, MusicSystem m, JFrame parent) {
        this.screenW = w;
        this.screenH = h;
        this.music = m;
        this.parent = parent;

        setPreferredSize(new Dimension(w, h));
        setFocusable(true);
        addKeyListener(this);

        gridW = cols * tileSize;
        gridH = rows * tileSize;
        gridX = (screenW - gridW) / 2;
        gridY = (screenH - gridH) / 2;

        // ----- Player -----
        player = new PlayerTrainer("Player", cols / 2, rows / 2);

        // ----- NPC Trainers -----
        npcLeft = new Trainer("Left NPC", 1, rows / 2);   // left side middle
        npcRight = new Trainer("Right NPC", cols - 2, rows / 2); // right side middle

        // ----- Pokemon Center -----
        pokeCenter = new PokemonCenter(3, 2); // top-left-ish position
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Water background
        g.setColor(new Color(173, 216, 230));
        g.fillRect(0, 0, screenW, screenH);

        // Grass grid
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int x = gridX + c * tileSize;
                int y = gridY + r * tileSize;

                Color base = new Color(110, 200, 90);
                g.setColor(((r + c) % 2 == 0) ? base : base.darker());
                g.fillRect(x, y, tileSize, tileSize);
            }
        }

        // Grid lines
        g.setColor(new Color(0, 0, 0, 80));
        for (int i = 1; i < cols; i++)
            g.drawLine(gridX + i * tileSize, gridY, gridX + i * tileSize, gridY + gridH);
        for (int i = 1; i < rows; i++)
            g.drawLine(gridX, gridY + i * tileSize, gridX + gridW, gridY + i * tileSize);

        // Urutan peting dari paling belakang ke paling  depan
        // 1. Draw Pokémon Center
        drawPokemonCenter(g, pokeCenter);

        // 2. Draw NPCs
        drawTrainer(g, npcLeft, Color.BLUE);
        drawTrainer(g, npcRight, Color.MAGENTA);

        // 3. Draw PLAYER LAST (always appears on top)
        drawTrainer(g, player, Color.RED);

        drawHUD(g);
        g.dispose();
    }

    private void drawTrainer(Graphics2D g, Trainer t, Color color) {
        int px = gridX + t.getCol() * tileSize;
        int py = gridY + t.getRow() * tileSize;

        // shadow
        g.setColor(new Color(0, 0, 0, 120));
        g.fillOval(px + 8, py + tileSize - 16, tileSize - 16, (tileSize - 16) / 3);

        // trainer circle
        g.setColor(color);
        g.fillOval(px + 8, py + 8, tileSize - 16, tileSize - 16);
    }

    private void drawPokemonCenter(Graphics2D g, PokemonCenter pc) {

        int startX = gridX + pc.getCol() * tileSize;
        int startY = gridY + pc.getRow() * tileSize;

        // Main building (2x2)
        for (int r = 0; r < pc.getHeight(); r++) {
            for (int c = 0; c < pc.getWidth(); c++) {
                int x = startX + c * tileSize;
                int y = startY + r * tileSize;

                g.setColor(new Color(255, 180, 180)); // light red building
                g.fillRect(x, y, tileSize, tileSize);

                g.setColor(Color.DARK_GRAY);
                g.drawRect(x, y, tileSize, tileSize);
            }
        }

        // Simple roof symbol (Pokéball-like circle)
        int cx = startX + tileSize;
        int cy = startY + tileSize;

        g.setColor(Color.WHITE);
        g.fillOval(cx - 12, cy - 12, 24, 24);

        g.setColor(Color.RED);
        g.fillOval(cx - 12, cy - 20, 24, 12);

        g.setColor(Color.BLACK);
        g.drawOval(cx - 12, cy - 12, 24, 24);
    }

    private void drawHUD(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 140));
        g.fillRoundRect(10, 10, 450, 130, 12, 12);

        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.PLAIN, 14));

        g.drawString("Player: " + player.getName(), 20, 35);
        g.drawString("Position: (" + player.getCol() + ", " + player.getRow() + ")", 20, 55);

        g.drawString("Pokémon: " + player.getPokemon().toString(), 20, 75);
        g.drawString("Items: " + player.getItems().toString(), 20, 95);

        g.drawString("Press ESC for Menu", 20, 120);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();

        if (k == KeyEvent.VK_ESCAPE) {
            new SettingsMenu(parent, player, music).setVisible(true);
            repaint();
            return;
        }

        if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W)
            player.move(0, -1, cols, rows);
        if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S)
            player.move(0, 1, cols, rows);
        if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A)
            player.move(-1, 0, cols, rows);
        if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D)
            player.move(1, 0, cols, rows);

        repaint();
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
}

