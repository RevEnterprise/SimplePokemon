public class Item {

    private String name;
    private int count;

    public Item(String name, int count) {
        this.name = name;
        this.count = count;
    }

    // Convenience constructor for single items
    public Item(String name) {
        this(name, 1);
    }

    // Copy constructor
    public Item(Item other) {
        this.name = other.name;
        this.count = other.count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = Math.max(0, count);
    }

    public void increase(int amount) {
        count = Math.max(0, count + amount);
    }

    public void decrease(int amount) {
        count = Math.max(0, count - amount);
    }

    @Override
    public String toString() {
        return name + " x" + count;
    }
}

