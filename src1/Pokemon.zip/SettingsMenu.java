import javax.swing.*;
import java.awt.*;

public class SettingsMenu extends JDialog {

    public SettingsMenu(JFrame parent, Trainer trainer, MusicSystem musicSystem) {
        super(parent, "Settings", true);
        setSize(420, 320);
        setLocationRelativeTo(parent);

        setLayout(new GridLayout(5, 1, 10, 10));

        // volume
        JPanel vol = new JPanel();
        vol.add(new JLabel("Volume: "));
        JSlider s = new JSlider(0, 100, (int)(musicSystem.getVolume()*100));
        s.addChangeListener(e -> musicSystem.setVolume(s.getValue() / 100f));
        vol.add(s);
        add(vol);

        JButton mus = new JButton("Switch Music Track");
        mus.addActionListener(e -> musicSystem.startMusicB());
        add(mus);

        JButton rearr = new JButton("Rearrange Pokémon");
        rearr.addActionListener(e -> new PokemonArrangeUI(parent, trainer).setVisible(true));
        add(rearr);

        JButton showItems = new JButton("View Items");
        showItems.addActionListener(e -> new ItemViewerUI(parent, trainer).setVisible(true));
        add(showItems);

        JButton exit = new JButton("Exit Game");
        exit.addActionListener(e -> System.exit(0));
        add(exit);
    }
}

