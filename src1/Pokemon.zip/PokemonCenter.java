public class PokemonCenter {

    private int col;
    private int row;

    /** Top-left tile of the Pokémon Center */
    public PokemonCenter(int col, int row) {
        this.col = col;
        this.row = row;
    }

    public int getCol() { return col; }
    public int getRow() { return row; }

    /** Returns width in tiles */
    public int getWidth() { return 2; }

    /** Returns height in tiles */
    public int getHeight() { return 2; }
}

