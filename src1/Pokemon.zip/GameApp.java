import javax.swing.*;

public class GameApp extends JFrame {

    private MusicSystem musicSystem;

    public GameApp() {
        setTitle("Trainer Exploration Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        musicSystem = new MusicSystem();
        musicSystem.startMusicA();

        WorldPanel panel = new WorldPanel(800, 600, musicSystem, this);
        setContentPane(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        panel.requestFocusInWindow();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameApp::new);
    }
}

