import javax.swing.*;

public class ItemViewerUI extends JDialog {

    public ItemViewerUI(JFrame parent, Trainer trainer) {
        super(parent, "Items", true);
        setSize(300, 350);
        setLocationRelativeTo(parent);

        DefaultListModel<String> model = new DefaultListModel<>();
        for (Item i : trainer.getItems())
            model.addElement(i.toString());

        JList<String> list = new JList<>(model);
        JScrollPane scroll = new JScrollPane(list);

        add(scroll);
    }
}

